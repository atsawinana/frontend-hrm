export const environment = {
  production: true,
  apiURL: "http://172.16.10.181/api/v1"
};
