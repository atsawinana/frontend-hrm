import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loading-department',
  templateUrl: './loading-department.component.html',
  styleUrls: ['./loading-department.component.css']
})
export class LoadingDepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
