import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unapproved',
  templateUrl: './unapproved.component.html',
  styleUrls: ['./unapproved.component.css']
})
export class UnapprovedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
