import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-info',
  templateUrl: './leave-info.component.html',
  styleUrls: ['./leave-info.component.css']
})
export class LeaveInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }



}
