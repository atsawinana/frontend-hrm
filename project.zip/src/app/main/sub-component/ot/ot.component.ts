import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ot',
  templateUrl: './ot.component.html',
  styleUrls: ['./ot.component.css']
})
export class OtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
