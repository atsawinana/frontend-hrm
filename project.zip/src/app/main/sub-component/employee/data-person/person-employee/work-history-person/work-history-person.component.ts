import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-history-person',
  templateUrl: './work-history-person.component.html',
  styleUrls: ['./work-history-person.component.css']
})
export class WorkHistoryPersonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
