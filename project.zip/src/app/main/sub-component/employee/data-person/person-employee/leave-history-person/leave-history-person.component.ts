import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-history-person',
  templateUrl: './leave-history-person.component.html',
  styleUrls: ['./leave-history-person.component.css']
})
export class LeaveHistoryPersonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
