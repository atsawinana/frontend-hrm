import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ot-history-person',
  templateUrl: './ot-history-person.component.html',
  styleUrls: ['./ot-history-person.component.css']
})
export class OtHistoryPersonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
