import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loading-emp',
  templateUrl: './loading-emp.component.html',
  styleUrls: ['./loading-emp.component.css']
})
export class LoadingEmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
