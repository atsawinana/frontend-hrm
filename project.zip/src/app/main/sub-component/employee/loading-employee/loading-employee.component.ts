import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loading-employee',
  templateUrl: './loading-employee.component.html',
  styleUrls: ['./loading-employee.component.css']
})
export class LoadingEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
