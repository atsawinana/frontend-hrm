import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travelExpenses',
  templateUrl: './travelExpenses.component.html',
  styleUrls: ['./travelExpenses.component.css']
})
export class TravelExpensesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
