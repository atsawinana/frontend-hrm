import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ot-noti',
  templateUrl: './ot-noti.component.html',
  styleUrls: ['./ot-noti.component.css']
})
export class OtNotiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
