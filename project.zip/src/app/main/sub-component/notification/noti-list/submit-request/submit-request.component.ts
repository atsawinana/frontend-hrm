import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submit-request',
  templateUrl: './submit-request.component.html',
  styleUrls: ['./submit-request.component.css']
})
export class SubmitRequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
