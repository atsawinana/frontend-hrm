import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-noti-list',
  templateUrl: './noti-list.component.html',
  styleUrls: ['./noti-list.component.css']
})
export class NotiListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
