import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-noti',
  templateUrl: './work-noti.component.html',
  styleUrls: ['./work-noti.component.css']
})
export class WorkNotiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
