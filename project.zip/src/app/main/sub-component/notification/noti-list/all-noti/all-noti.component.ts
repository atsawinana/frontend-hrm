import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-noti',
  templateUrl: './all-noti.component.html',
  styleUrls: ['./all-noti.component.css']
})
export class AllNotiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
