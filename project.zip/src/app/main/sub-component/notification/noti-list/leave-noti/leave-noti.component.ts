import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-noti',
  templateUrl: './leave-noti.component.html',
  styleUrls: ['./leave-noti.component.css']
})
export class LeaveNotiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
