import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timeAttendance',
  templateUrl: './timeAttendance.component.html',
  styleUrls: ['./timeAttendance.component.css']
})
export class TimeAttendanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
